# Cryptocurrency Platform Audit Sources

This note preserves the external control references consulted for the platform audit on 20 August 2026.

| Source | Audit takeaway | URL |
| --- | --- | --- |
| OWASP API Security Top 10, API4:2023 | Public listings, alerts, login/recovery, webhooks, uploads, and API-backed tools need endpoint-specific rate limits, request/payload caps, pagination controls, provider cost limits, and billing alerts to reduce denial-of-service and cost-exhaustion risk. | https://owasp.org/API-Security/editions/2023/en/0xa4-unrestricted-resource-consumption/ |
| NIST SP 800-63B / current SP 800-63 guidance notice | Authentication needs lifecycle treatment rather than just initial login; the current site should plan factor enrollment, recovery, session management, and privacy-aware account operations. The extracted page notes that SP 800-63B was superseded by SP 800-63-4 in August 2025. | https://pages.nist.gov/800-63-3/sp800-63b.html |
| CISA Incident Response | Organizations need an executable incident-response plan that supports prevention, detection, response, and recovery; the platform therefore requires owners, escalation paths, logging, notification rules, and tested playbooks before live wallet, payment, or marketplace activity. | https://www.cisa.gov/topics/cyber-threats-and-response/incident-response |
