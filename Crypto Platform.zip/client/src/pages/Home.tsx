/**
 * Network Desk design: an editorial systems map for the supplied cryptocurrency
 * platform feature set. It intentionally avoids live market claims, labels
 * integration-dependent capabilities as handoffs, and uses a signal-rail
 * readiness register to make product-control dependencies visible.
 */
import { useMemo, useState } from "react";
import {
  ArrowDownRight,
  ArrowRight,
  BellRing,
  BookOpen,
  Braces,
  ChevronDown,
  CircleDollarSign,
  Code2,
  Droplets,
  FileKey2,
  Globe2,
  LayoutDashboard,
  LineChart,
  Menu,
  PackageOpen,
  Search,
  ShieldCheck,
  Sparkles,
  Store,
  WalletCards,
  X,
} from "lucide-react";

type Module = {
  id: string;
  number: string;
  tag: string;
  title: string;
  short: string;
  route: string;
  capabilities: string[];
  backend: string;
  dependencies: string[];
  icon: typeof LineChart;
  tone: "lime" | "violet" | "coral" | "blue";
};

const modules: Module[] = [
  {
    id: "market",
    number: "01",
    tag: "MARKET DATA",
    title: "Coin & token detail",
    short: "A structured market-data layer for listings, asset detail, charting, supply, volume, and exchange context.",
    route: "/coins · /coins/[id]",
    capabilities: ["Coin list and asset detail", "Price, change, cap, supply, volume, and exchange context", "Chart.js visual layer", "Cached CoinGecko service with cron refresh"],
    backend: "CoinGecko integration, cache service, GET /api/coins and GET /api/coins/:id.",
    dependencies: ["Shared search", "Alert engine", "Portfolio tools"],
    icon: LineChart,
    tone: "lime",
  },
  {
    id: "learn",
    number: "02",
    tag: "KNOWLEDGE",
    title: "Blog & glossary",
    short: "An editorial and vocabulary layer that gives people trustworthy context around assets and the language used to describe them.",
    route: "/blog · /blog/[slug] · /glossary",
    capabilities: ["SEO-aware blog listing and article pages", "Category filters and publishing workflow", "A–Z glossary with detail modal and tooltips", "Admin content management"],
    backend: "Blog and glossary routes, role-gated authoring endpoints, and shared type contracts.",
    dependencies: ["Global search", "Notifications", "Admin CMS"],
    icon: BookOpen,
    tone: "violet",
  },
  {
    id: "faucets",
    number: "03",
    tag: "FAUCET DIRECTORY",
    title: "Faucet listings",
    short: "A filtered directory for faucet sources, supported coins, payout methods, and claimed intervals—managed as a reviewable information service.",
    route: "/faucets",
    capabilities: ["Faucet source directory", "Coin and payout-method filters", "Source, supported coins, payout method, and interval fields", "Admin add and edit workflow"],
    backend: "GET /api/faucets for the directory and role-gated POST /api/faucets for operational management.",
    dependencies: ["Global search", "Alerts", "Admin CMS"],
    icon: Droplets,
    tone: "blue",
  },
  {
    id: "wallet",
    number: "04",
    tag: "ACCOUNT ACCESS",
    title: "Email & wallet identity",
    short: "A single account layer where email sign-in and connected-wallet access can coexist without blurring their security boundaries.",
    route: "/auth · /dashboard",
    capabilities: ["JWT email/password registration and login", "MetaMask wallet login", "Profile and dashboard management", "WalletConnect-ready integration boundary"],
    backend: "Auth routes, wallet-verification flow, user profile endpoint, and role middleware.",
    dependencies: ["Alerts", "Marketplace checkout", "Admin access"],
    icon: WalletCards,
    tone: "blue",
  },
  {
    id: "alerts",
    number: "05",
    tag: "SIGNAL DELIVERY",
    title: "Alerts & notifications",
    short: "A preferences-led notification system for price thresholds and updates to articles or faucet listings.",
    route: "/dashboard/alerts",
    capabilities: ["Coin threshold alerts", "News and faucet update alerts", "Email and push delivery", "Preference storage and scheduled delivery"],
    backend: "Alert settings, notification service, scheduled dispatch, and OneSignal handoff.",
    dependencies: ["Coin cache", "Blog", "Faucets", "Identity"],
    icon: BellRing,
    tone: "coral",
  },
  {
    id: "tools",
    number: "06",
    tag: "PERSONAL UTILITIES",
    title: "Portfolio & calculators",
    short: "Practical utility surfaces for portfolio tracking, conversion calculation, and gas awareness with clear data-source boundaries.",
    route: "/tools/portfolio · /tools/converter · /tools/gas",
    capabilities: ["Local-first portfolio tracker", "Conversion calculator", "Gas tracker", "Optional authenticated portfolio save"],
    backend: "Coin data bridge, local storage baseline, and optional profile sync routes.",
    dependencies: ["Coin cache", "Identity", "Shared configuration"],
    icon: CircleDollarSign,
    tone: "lime",
  },
  {
    id: "marketplace",
    number: "07",
    tag: "COMMERCE",
    title: "Digital marketplace",
    short: "A moderated crypto-commerce workspace for products, seller uploads, approvals, carts, and wallet-aware checkout.",
    route: "/marketplace · /marketplace/[productId]",
    capabilities: ["Product discovery and detail", "Seller upload and listing review", "Cart and crypto checkout", "Payment-webhook integration boundary"],
    backend: "Product CRUD, admin approvals, payment webhook validation, and order records.",
    dependencies: ["Identity", "Wallet login", "Admin controls"],
    icon: Store,
    tone: "violet",
  },
  {
    id: "ops",
    number: "08",
    tag: "OPERATIONS",
    title: "Admin & shared system",
    short: "The operational layer that keeps permissions, content, listings, logs, analytics, themes, search, and shared types coherent.",
    route: "/admin · /api/admin/*",
    capabilities: ["Role-gated administration", "Users, content, glossary, faucets, and listings", "API logs and analytics", "Shared search, themes, toasts, types, and API configuration"],
    backend: "Admin routes, authorization middleware, operational logs, shared types, and constants.",
    dependencies: ["Every product module"],
    icon: LayoutDashboard,
    tone: "blue",
  },
];

const buildOrder = [
  ["00A", "Feature boundary & policy map", "Set the jurisdiction, prohibited activity, vendor, data-classification, retention, and escalation map before collecting data or enabling account actions."],
  ["00B", "Security, recovery & secrets", "Complete threat modelling, wallet-signature binding, session and recovery design, least-privilege roles, secret handling, and dependency scanning before live identity."],
  ["01", "Shared contracts & API perimeter", "Define shared types, versioned API contracts, endpoint-specific rate limits, payload caps, audit logging, and spend limits before feature work begins."],
  ["02", "Identity and access", "Establish email and wallet identity with multi-factor options, re-authentication for sensitive actions, recoverable account flows, roles, and permissions."],
  ["03", "Market data foundation", "Add cached market sources with timestamps, source labels, failure handling, shared search, and clear refresh semantics—never implied live certainty."],
  ["04", "Editorial, vocabulary & faucets", "Release reviewable editorial and faucet flows with evidence fields, verification dates, report-abuse tools, filters, disclosure, and administration."],
  ["05", "Tools and alerts", "Layer local-first utilities and user-controlled signals over approved data, bounded schedules, consented delivery channels, and unsubscribe controls."],
  ["06", "Marketplace controls", "Add seller eligibility, restricted-item rules, catalog review, idempotent webhook verification, buyer dispute paths, and a no-funds-held launch boundary."],
  ["07", "Pre-live evidence gate", "Require accessibility checks, privacy and deletion tests, abuse and recovery drills, security review, vendor review, and critical-path failure tests before public activation."],
  ["08", "Progressive release & response", "Launch by feature flag and cohort, observe data freshness and abuse signals, test the incident playbook, and retain the ability to pause high-risk flows."],
  ["09", "Operations and future modules", "Operate the reviewed core with measurable ownership, then stage mobile, AI, forum, and community work behind their own readiness gates."],
];

const architecture = [
  { label: "Frontend", value: "Next.js · React · TypeScript", icon: Code2 },
  { label: "Backend", value: "Node.js · Express or NestJS", icon: Braces },
  { label: "Data", value: "MongoDB · shared contracts", icon: FileKey2 },
  { label: "Integrations", value: "CoinGecko · MetaMask · WalletConnect · OneSignal", icon: Globe2 },
];

type Control = {
  id: string;
  priority: "P0" | "P1";
  area: string;
  gap: string;
  control: string;
  owner: string;
  evidence: string;
  phase: string;
};

const readinessControls: Control[] = [
  { id: "identity", priority: "P0", area: "Account and wallet recovery", gap: "Email and wallet sign-in are scoped, but recovery, sensitive-action re-authentication, session revocation, and a safe wallet-change path are not yet release-gated.", control: "Use explicit account-linking rules, factor enrollment and recovery controls, short-lived sensitive sessions, session revocation, and signed nonce verification with chain and origin allow-lists.", owner: "Security + identity", evidence: "Threat model, recovery drill, session-revocation test, and wallet-binding negative tests.", phase: "00B → 02" },
  { id: "payments", priority: "P0", area: "Marketplace payment boundary", gap: "Checkout and webhook validation are named, but seller eligibility, restricted goods, duplicate delivery, buyer disputes, and custody boundaries are not defined.", control: "Launch with reviewed sellers, restricted-item rules, idempotency keys, signature-verified webhooks, order reconciliation, dispute handling, and no platform-held customer funds until legal and operational controls are approved.", owner: "Commerce + legal", evidence: "Webhook replay test, seller suspension drill, reconciliation report, and signed launch policy.", phase: "06 → 07" },
  { id: "faucets", priority: "P0", area: "Faucet trust and abuse", gap: "A directory can amplify misleading payout claims, malicious destinations, or rapidly changing source terms if entries are only filterable.", control: "Require evidence-backed listings, verification dates, terms and destination checks, report-abuse workflow, removal SLA, clear risk disclosures, and no implied endorsement.", owner: "Content operations", evidence: "Listing review record, quarterly re-check sample, abuse-report route, and removal drill.", phase: "04 → 07" },
  { id: "data", priority: "P0", area: "Data provenance and freshness", gap: "Cached market data is planned, but source attribution, freshness states, provider failure behaviour, and conflicting-value handling are not visible.", control: "Label source and last-updated time, define stale and unavailable states, cap cache age, monitor provider errors, and publish a provider-failover and correction procedure.", owner: "Data platform", evidence: "Freshness dashboard, simulated provider outage, source-label review, and correction log.", phase: "01 → 03" },
  { id: "api", priority: "P0", area: "API abuse and vendor cost", gap: "Public search, alerts, login, faucets, uploads, and third-party integrations have no stated endpoint quotas or spend guardrails.", control: "Apply endpoint and actor-specific rate limits, request-size and pagination caps, webhook replay defense, vendor budgets, billing alerts, and abuse telemetry.", owner: "Platform engineering", evidence: "Load test, rate-limit test, vendor-budget alert, and API inventory review.", phase: "01 → 07" },
  { id: "incident", priority: "P0", area: "Incident response and pause authority", gap: "Admin logs are proposed, but the platform lacks owned on-call paths, containment steps, notification rules, and authority to pause risky flows.", control: "Maintain severity definitions, named incident roles, response and communications playbooks, immutable security event trails, drills, and feature-level kill switches.", owner: "Security operations", evidence: "Tabletop exercise, kill-switch test, incident ticket template, and escalation roster.", phase: "00A → 08" },
  { id: "privacy", priority: "P1", area: "Privacy and lifecycle", gap: "Profiles, alerts, analytics, and portfolio saves introduce personal data, but purpose limits, consent records, retention, export, and deletion are not yet specified.", control: "Create a data inventory, consent and preference events, retention schedule, export and deletion workflow, access logging, and vendor data-processing review before optional sync is enabled.", owner: "Privacy + product", evidence: "Data map, deletion rehearsal, consent audit sample, and vendor register.", phase: "00A → 07" },
  { id: "content", priority: "P1", area: "Editorial and AI integrity", gap: "Educational material and a future AI assistant can blur source context, promotional claims, moderation, and generated-answer reliability.", control: "Adopt editorial disclosure standards, citations and corrections, conflict labelling, human review for high-risk content, AI source boundaries, prompt-injection testing, and model-change review.", owner: "Editorial + AI governance", evidence: "Editorial policy, correction log, AI red-team sample, and model-change approval.", phase: "04 → 09" },
  { id: "supply", priority: "P1", area: "Secure delivery and secrets", gap: "The planned frontend, backend, integrations, and shared contracts do not yet state environment separation, dependency assurance, or secret rotation.", control: "Separate environments, keep secrets server-side, scan dependencies and infrastructure changes, protect branches, review permissions, and practise credential rotation.", owner: "Engineering enablement", evidence: "CI security checks, secret-rotation record, environment access review, and release approval.", phase: "00B → 07" },
  { id: "inclusion", priority: "P1", area: "Accessibility and regional readiness", gap: "The product includes dense data, wallet flows, alerts, and commerce, but no accessibility baseline, language strategy, or regional eligibility design is defined.", control: "Set accessible interaction and contrast acceptance criteria, keyboard and screen-reader tests, localization-ready copy, timezone handling, and feature eligibility by jurisdiction.", owner: "Design + product", evidence: "Accessibility audit, keyboard test, localization review, and eligibility matrix.", phase: "00A → 07" },
];

export default function Home() {
  const [activeModule, setActiveModule] = useState(modules[0].id);
  const [openStep, setOpenStep] = useState("00");
  const [navOpen, setNavOpen] = useState(false);
  const [faucetFilter, setFaucetFilter] = useState("All sources");
  const [controlFilter, setControlFilter] = useState<"All" | "P0" | "P1">("All");
  const [openControl, setOpenControl] = useState(readinessControls[0].id);
  const selectedModule = useMemo(() => modules.find((item) => item.id === activeModule) ?? modules[0], [activeModule]);
  const visibleControls = readinessControls.filter((item) => controlFilter === "All" || item.priority === controlFilter);
  const ActiveIcon = selectedModule.icon;

  const goTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
    setNavOpen(false);
  };

  return (
    <div className="network-app">
      <header className="network-header">
        <button className="brand-lockup" onClick={() => goTo("top")} aria-label="Go to the cryptocurrency platform overview">
          <span className="brand-mark" aria-hidden="true"><i /><b /><em /></span>
          <span><strong>Crypto Platform</strong><small>FULL FEATURE SET</small></span>
        </button>
        <nav className={navOpen ? "network-nav network-nav-open" : "network-nav"} aria-label="Primary navigation">
          <button onClick={() => goTo("modules")}>Modules</button>
          <button onClick={() => goTo("architecture")}>Architecture</button>
          <button onClick={() => goTo("delivery")}>Build order</button>
          <button onClick={() => goTo("readiness")}>Readiness</button>
          <button onClick={() => goTo("future")}>Future scope</button>
        </nav>
        <button className="header-action" onClick={() => goTo("modules")}><Search size={16} /> Explore system <ArrowRight size={16} /></button>
        <button className="nav-toggle" onClick={() => setNavOpen((open) => !open)} aria-label="Toggle navigation">{navOpen ? <X /> : <Menu />}</button>
      </header>

      <main id="top">
        <section className="hero-section" aria-labelledby="hero-title">
          <div className="hero-copy">
            <p className="protocol-label"><span /> MODULAR CRYPTOCURRENCY PLATFORM</p>
            <h1 id="hero-title">One clear system for the <em>signal,</em> the story, and the next action.</h1>
            <p className="hero-lead">A full-feature product blueprint spanning market data, learning, wallet access, alerts, tools, a moderated marketplace, and operational controls.</p>
            <div className="hero-actions">
              <button className="primary-button" onClick={() => goTo("modules")}>Explore the feature map <ArrowDownRight size={18} /></button>
              <button className="quiet-button" onClick={() => goTo("architecture")}>Read the architecture</button>
            </div>
            <p className="disclaimer">Product blueprint only. Market data, wallet actions, payments, and notifications require configured services; nothing here is financial advice.</p>
          </div>
          <div className="hero-map" aria-label="Illustrative system map">
            <div className="map-orbit orbit-one" /><div className="map-orbit orbit-two" /><div className="map-grid" />
            <div className="map-core"><span>CORE</span><strong>Shared<br />system</strong></div>
            {modules.slice(0, 6).map((item, index) => <button key={item.id} className={`map-node node-${index + 1} tone-${item.tone}`} onClick={() => { setActiveModule(item.id); goTo("modules"); }}><span>{item.number}</span><b>{item.tag.split(" ")[0]}</b></button>)}
            <p className="map-caption"><span className="pulse-dot" /> implementation map · not live market activity</p>
          </div>
        </section>

        <section className="signal-strip" aria-label="Platform summary">
          <div><span>08</span><p>Connected product<br /><b>modules</b></p></div>
          <div><span>03</span><p>Application layers<br /><b>frontend · backend · shared</b></p></div>
          <div><span>04</span><p>Future directions<br /><b>mobile · AI · forum · community</b></p></div>
          <button onClick={() => goTo("delivery")}>View the build sequence <ArrowRight size={15} /></button>
        </section>

        <section className="content-section module-section" id="modules" aria-labelledby="modules-title">
          <div className="section-heading"><div className="route-caption"><span>N01</span><i /><b>MODULE ROUTE</b></div><p className="protocol-label"><span /> PRODUCT MODULES</p><h2 id="modules-title">A platform that moves <em>as one system.</em></h2><p>Choose a node to see its product surface, operating contract, and relationships across the platform.</p></div>
          <div className="module-layout">
            <aside className="module-rail" aria-label="Platform modules">
              {modules.map((item) => { const Icon = item.icon; return <button key={item.id} className={activeModule === item.id ? `module-link is-active tone-${item.tone}` : "module-link"} onClick={() => setActiveModule(item.id)}><span>{item.number}</span><Icon size={17} /><b>{item.title}</b><ArrowRight size={15} /></button>; })}
            </aside>
            <article className={`module-detail tone-${selectedModule.tone}`} aria-live="polite">
              <div className="detail-topline"><p className="protocol-label">{selectedModule.tag}</p><span>{selectedModule.route}</span></div>
              <div className="detail-title"><span className="detail-icon"><ActiveIcon size={27} /></span><div><h3>{selectedModule.title}</h3><p>{selectedModule.short}</p></div></div>
              <div className="detail-grid"><div><h4>Product contract</h4><ul>{selectedModule.capabilities.map((item) => <li key={item}>{item}</li>)}</ul></div><div><h4>Implementation handoff</h4><p>{selectedModule.backend}</p><h4 className="dependency-title">Connected modules</h4><div className="dependency-pills">{selectedModule.dependencies.map((item) => <span key={item}>{item}</span>)}</div></div></div>
              {selectedModule.id === "faucets" && <div className="faucet-preview" aria-label="Faucet directory contract preview"><div className="faucet-preview-head"><div><span>DIRECTORY PREVIEW</span><b>/faucets</b></div><small>data connection required</small></div><div className="faucet-filters" aria-label="Faucet directory filters">{["All sources", "BTC", "ETH", "Instant payout", "Timed payout"].map((filter) => <button key={filter} onClick={() => setFaucetFilter(filter)} className={faucetFilter === filter ? "is-selected" : ""}>{filter}</button>)}</div><div className="faucet-columns"><span>Source</span><span>Supported coins</span><span>Payout method</span><span>Interval</span></div><div className="faucet-empty"><Droplets size={18} /><div><b>{faucetFilter} listing contract</b><p>Approved directory records load from <code>GET /api/faucets</code>. Source claims and payout terms need review before publication.</p></div></div></div>}
              <div className="detail-note"><ShieldCheck size={16} /><p><b>Integration boundary:</b> This is a product-specification view. Live price, wallet, crypto-payment, scheduled-notification, and administrative actions are enabled only after the required backend services and credentials are configured.</p></div>
            </article>
          </div>
        </section>

        <section className="architecture-section" id="architecture" aria-labelledby="architecture-title">
          <div className="section-heading invert"><div className="route-caption"><span>SYS 00</span><i /><b>FOUNDATION LINE</b></div><p className="protocol-label"><span /> SYSTEM FOUNDATION</p><h2 id="architecture-title">Build the shared layer <em>once.</em></h2><p>The feature set stays modular because its contracts, identity, configuration, and operational guardrails are shared deliberately.</p></div>
          <div className="architecture-grid">{architecture.map(({ label, value, icon: Icon }, index) => <article key={label} className="architecture-card"><span>0{index + 1}</span><Icon size={25} /><p>{label}</p><h3>{value}</h3></article>)}</div>
          <div className="system-line"><span>Shared types</span><i /><span>Global search</span><i /><span>Theme and toasts</span><i /><span>Role controls</span><i /><span>API configuration</span></div>
        </section>

        <section className="content-section delivery-section" id="delivery" aria-labelledby="delivery-title">
          <div className="section-heading"><div className="route-caption"><span>R05</span><i /><b>DEPENDENCY PATH</b></div><p className="protocol-label"><span /> DELIVERY SEQUENCE</p><h2 id="delivery-title">A practical order for <em>building without drift.</em></h2><p>Each step resolves a dependency that makes the next product surface safer, easier to operate, and less expensive to rework.</p></div>
          <div className="build-list">{buildOrder.map(([number, title, detail]) => <article key={number} className={openStep === number ? "build-step is-open" : "build-step"}><button onClick={() => setOpenStep(openStep === number ? "" : number)} aria-expanded={openStep === number}><span>{number}</span><b>{title}</b><ChevronDown size={19} /></button>{openStep === number && <div className="build-detail"><p>{detail}</p><span>Required before moving forward</span></div>}</article>)}</div>
        </section>

        <section className="readiness-section" id="readiness" aria-labelledby="readiness-title">
          <div className="section-heading readiness-heading"><div className="route-caption"><span>G06</span><i /><b>RELEASE GATES</b></div><p className="protocol-label"><span /> PRODUCT AUDIT</p><h2 id="readiness-title">The missing work is not more features. It is <em>proof that the features hold.</em></h2><p>The platform scope is preserved. These controls add the security, operational, data, and delivery gates needed before live identity, payments, marketplace, or alert activity can safely expand.</p></div>
          <div className="readiness-summary"><div><span>10</span><p>release controls<br /><b>mapped to owners and evidence</b></p></div><div><span>06</span><p>priority-zero gates<br /><b>before public high-risk flows</b></p></div><div><span>03</span><p>new prerequisite stages<br /><b>policy · recovery · proof</b></p></div></div>
          <div className="control-toolbar" aria-label="Filter audit controls"><p>Filter the control register</p><div>{(["All", "P0", "P1"] as const).map((item) => <button key={item} onClick={() => setControlFilter(item)} className={controlFilter === item ? "is-active" : ""}>{item === "All" ? "All controls" : `${item} priority`}</button>)}</div></div>
          <div className="control-grid">{visibleControls.map((item, index) => <article key={item.id} className={openControl === item.id ? `control-card is-open priority-${item.priority.toLowerCase()}` : `control-card priority-${item.priority.toLowerCase()}`}><button onClick={() => setOpenControl(openControl === item.id ? "" : item.id)} aria-expanded={openControl === item.id}><span>{String(index + 1).padStart(2, "0")}</span><small>{item.priority} · {item.phase}</small><h3>{item.area}</h3><ChevronDown size={18} /></button><p className="control-gap"><b>Gap</b>{item.gap}</p>{openControl === item.id && <div className="control-detail"><div><small>Corrective control</small><p>{item.control}</p></div><div className="control-meta"><span><b>Owner</b>{item.owner}</span><span><b>Release evidence</b>{item.evidence}</span></div></div>}</article>)}</div>
          <aside className="readiness-note"><ShieldCheck size={19} /><div><b>Control rule</b><p>Do not advance a high-risk feature on intent alone. Its owner must show the listed evidence, record exceptions, and retain the ability to pause the feature.</p></div></aside>
        </section>

        <section className="tools-callout" aria-labelledby="tools-title"><div><div className="route-caption"><span>T04</span><i /><b>UTILITY LINE</b></div><p className="protocol-label"><span /> UTILITY SURFACES</p><h2 id="tools-title">Useful tools should show their <em>data boundary.</em></h2><p>Portfolio tracking can begin locally; a conversion calculator and gas tracker depend on an approved data source. Authenticated saving is optional, never assumed.</p></div><div className="tool-preview"><div className="tool-preview-head"><span>CONVERTER PREVIEW</span><small>illustrative only</small></div><div className="converter-row"><span>1.00</span><i /><span>data source required</span></div><div className="tool-preview-foot"><CircleDollarSign size={15} /> Build in <b>/tools/converter</b></div></div></section>

        <section className="future-section" id="future" aria-labelledby="future-title"><div className="future-copy"><div className="route-caption"><span>E07</span><i /><b>EXTENSION PATH</b></div><p className="protocol-label"><span /> STAGED EXTENSIONS</p><h2 id="future-title">Future scope stays visible—<em>not rushed.</em></h2><p>Mobile, AI, forum, and community systems belong on the map now, while their implementation waits for the common platform, governance, and observability layers they require.</p></div><div className="future-grid"><article><PackageOpen size={22} /><span>01</span><h3>Mobile app</h3><p>React Native or Flutter workspace aligned to shared contracts.</p></article><article><Sparkles size={22} /><span>02</span><h3>AI assistant</h3><p>Coin context and article summaries with defined disclosure and review.</p></article><article><Globe2 size={22} /><span>03</span><h3>Forum</h3><p>Threads, comments, votes, and a moderation-ready community layer.</p></article><article><ShieldCheck size={22} /><span>04</span><h3>Leaderboard</h3><p>Community signals only after anti-abuse and participation rules exist.</p></article></div></section>
      </main>

      <footer className="network-footer"><div className="footer-brand"><span className="brand-mark" aria-hidden="true"><i /><b /><em /></span><strong>Crypto Platform</strong></div><p>Full feature-set overview based on the supplied project content. No live market, trading, payment, or wallet activity is executed by this static preview.</p><button onClick={() => goTo("top")}>Back to top <ArrowRight size={15} /></button></footer>
    </div>
  );
}
